import os, json, boto3, bcrypt, jwt
from datetime import datetime, timedelta

table = boto3.resource("dynamodb").Table(os.environ["TABLE_NAME"])
JWT_SECRET = os.environ.get("JWT_SECRET", "change_this_secret")
JWT_ALGORITHM = "HS256"
JWT_EXPIRE_MINUTES = 60

def lambda_handler(event, context):
    body = json.loads(event.get("body", "{}"))
    email = body.get("email")
    password = body.get("password")

    if not email or not password:
        return {"statusCode": 400, "headers": {"Access-Control-Allow-Origin": "*"}, "body": json.dumps({"error": "Missing fields"})}

    user = table.get_item(Key={"email": email}).get("Item")
    if not user or not bcrypt.checkpw(password.encode(), user["password"].encode()):
        return {"statusCode": 401, "headers": {"Access-Control-Allow-Origin": "*"}, "body": json.dumps({"error": "Invalid credentials"})}

    token = jwt.encode(
        {"sub": email, "exp": datetime.utcnow() + timedelta(minutes=JWT_EXPIRE_MINUTES)},
        JWT_SECRET,
        algorithm=JWT_ALGORITHM
    )

    return {"statusCode": 200, "headers": {"Access-Control-Allow-Origin": "*"}, "body": json.dumps({"token": token})}