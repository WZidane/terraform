import os, json, boto3, bcrypt, uuid
from datetime import datetime

table = boto3.resource("dynamodb").Table(os.environ["TABLE_NAME"])

def lambda_handler(event, context):
    body = json.loads(event.get("body", "{}"))
    first_name = body.get("first_name")
    last_name = body.get("last_name")
    email = body.get("email")
    password = body.get("password")

    if not all([first_name, last_name, email, password]):
        return {
            "statusCode": 400,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps({"error": "Missing fields"})
        }

    if table.get_item(Key={"email": email}).get("Item"):
        return {
            "statusCode": 400,
            "headers": {"Access-Control-Allow-Origin": "*"},
            "body": json.dumps({"error": "User already exists"})
        }

    hashed_pw = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode()
    now = datetime.utcnow().isoformat()
    user_id = str(uuid.uuid4())

    table.put_item(Item={
        "id": user_id,
        "first_name": first_name,
        "last_name": last_name,
        "email": email,
        "password": hashed_pw,
        "created_at": now,
        "updated_at": now
    })

    return {
        "statusCode": 200,
        "headers": {"Access-Control-Allow-Origin": "*"},
        "body": json.dumps({"message": "User created"})
    }